from django.db import models


# Create your models here.
class UserInfo(models.Model):

    username = models.CharField(max_length=32,unique=True,verbose_name="username")
    password = models.CharField(max_length=64,verbose_name="password")
    create_time = models.DateTimeField(auto_now=True,verbose_name="time")

    def __str__(self):
        return self.username

    class Meta:
        verbose_name = "user"
        verbose_name_plural = verbose_name
        db_table = 'UserInfo'


class allocation_list(models.Model):

    # group_id = models.IntegerField(verbose_name="group_id")
    group = models.ForeignKey(verbose_name="group_id",to="group_preference")
    # project_id = models.IntegerField(verbose_name='project_id')
    project = models.ForeignKey(verbose_name='project_id',to="project_infos")


    def __str__(self):
        return str(self.group.group_name)

    class Meta:
        verbose_name = "allocation_list"
        verbose_name_plural = verbose_name
        db_table = 'allocation_list'




# Create your models here.
class vacancy_list(models.Model):

    project = models.ForeignKey(to="project_infos", verbose_name='project_id')
    # project = models.IntegerField(verbose_name='project_id')
    number_of_groups_allowed = models.BooleanField(verbose_name='number_of_groups_allowed')
    number_of_groups_allocated = models.BooleanField(verbose_name='number_of_groups_allocated')

    def __str__(self):
        return str(self.project)

    class Meta:
        verbose_name = "vacancy_list"
        verbose_name_plural = verbose_name
        db_table = 'vacancy_list'




#Create allocation condition
class allocation_condition(models.Model):

    project_id = models.IntegerField(verbose_name='project_id')
    number_of_groups_allowed = models.IntegerField(verbose_name='number_of_groups_allowed')
    number_of_groups_allocated = models.IntegerField(verbose_name='number_of_groups_allocated')

    def __str__(self):
        return str(self.project_id)

    class Meta:
        verbose_name = "allocation_condition"
        verbose_name_plural = verbose_name
        db_table = 'allocation_condition'


class project_infos(models.Model):

    group_id = models.IntegerField(verbose_name="group_id")
    title = models.CharField(max_length=255,null=False,verbose_name='title')
    number_of_groups_allowed = models.IntegerField(verbose_name='number_of_groups_allowed')

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = "project_infos"
        verbose_name_plural = verbose_name
        db_table = 'project_infos'




class student_group(models.Model):

    student_id = models.IntegerField(verbose_name="student_id")
    uni_key = models.CharField(max_length=255,verbose_name='uni_key')
    group = models.ForeignKey(verbose_name="group", to="group_preference")

    def __str__(self):
        return str(self.student_id)

    class Meta:
        verbose_name = "student_group"
        verbose_name_plural = verbose_name
        db_table = 'student_group'




class group_preference(models.Model):

    group_name = models.CharField(verbose_name='group_name',max_length=255)
    project_pref1 = models.CharField(verbose_name='project_pref1',max_length=255)
    project_pref2 = models.CharField(verbose_name='project_pref2',max_length=255)
    project_pref3 = models.CharField(verbose_name='project_pref3',max_length=255)

    def __str__(self):
        return self.group_name

    class Meta:
        verbose_name = "group_preference"
        verbose_name_plural = verbose_name
        db_table = 'group_preference'



