from rest_framework.views import APIView
from django.shortcuts import render


# 数据首页
class Upload(APIView):
    def get(self,request):
        return render(request, "upload.html")