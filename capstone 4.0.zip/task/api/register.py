import re

from rest_framework.views import APIView
from django.shortcuts import render,redirect,HttpResponse
from database import models
from django.http import JsonResponse


class Register(APIView):
    authentication_classes = []
    def get(self,request):
        return render(request, "login.html")

    def post(self,request):
        username = str(request.data.get("register_username"))
        password = str(request.data.get("register_password"))
        message = {}

        # 判断
        phone_pat = re.compile('[@]')
        res = re.search(phone_pat, username)
        if not res:
            message['code'] = 10002
            return JsonResponse(message)

        try:
            models.UserInfo.objects.create(username=username,password=password)
            message['code'] = 200
            message['message'] = "registration success"
            return JsonResponse(message)
        except Exception as e:
            print(e)
            message['code'] = 444
            message['message'] = "registration failure"
            return JsonResponse(message)