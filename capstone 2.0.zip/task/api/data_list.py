from rest_framework.views import APIView
from django.shortcuts import render,redirect,HttpResponse
from database import models
from django.http import JsonResponse
import random

class Data(APIView):

    def get(self,request):

        message = {}

        try:
            data_f= []
            number_of_groups_allowed_set = models.allocation_condition.objects.all()
            for obj in number_of_groups_allowed_set:
                dict_f = {}
                dict_f['hc-a2'] = "P" + str(obj.project_id)
                dict_f['name'] = "P" + str(obj.project_id)
                dict_f['region'] = "South"
                dict_f['x'] = int(obj.project_id/5)
                dict_f['y'] = obj.project_id%5
                dict_f['value'] = obj.number_of_groups_allowed - obj.number_of_groups_allocated
                data_f.append(dict_f)


            message['code'] = 200
            message['message'] = "registration success"
            message['data'] = data_f


            return JsonResponse(message)
        except Exception as e:
            print(e)
            message['code'] = 444
            message['message'] = "registration failure"
            return JsonResponse(message)


    '''

    def tyope(self,x):
        dict = {True:1,False:0}
        res = dict[x]
        return res
    '''