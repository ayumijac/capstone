from django.contrib import admin

# Register your models here.

from django.http import HttpResponse

from database import models
# Register your models here.

from openpyxl import Workbook


class UserInfoAdmin(admin.ModelAdmin):

    list_display = ('username','create_time',)
    list_filter = ['username','create_time']

    actions = ["export_as_excel"]
    def export_as_excel(self, request, queryset):
        meta = self.model._meta  # 用于定义文件名, 格式为: app名.模型类名
        field_names = [field.name for field in meta.fields]  # 模型所有字段名
        response = HttpResponse(content_type='application/msexcel')  # 定义响应内容类型
        response['Content-Disposition'] = f'attachment; filename={meta}.xlsx'  # 定义响应数据格式
        wb = Workbook()  # 新建Workbook
        ws = wb.active  # 使用当前活动的Sheet表
        ws.append(field_names)  # 将模型字段名作为标题写入第一行
        for obj in queryset:  # 遍历选择的对象列表

            for field in field_names:
                data = [f'{getattr(obj, field)}' for field in field_names]  # 将模型属性值的文本格式组成列表
            ws.append(data)
        wb.save(response)
        return response

    export_as_excel.short_description = '导出Excel'  # 该动作在admin中的显示文字


admin.site.register(models.UserInfo, UserInfoAdmin)






class allocation_listAdmin(admin.ModelAdmin):

    list_display = ('group_id', 'project_id',)
    list_filter = ['group_id', 'project_id',]
    list_per_page = 15
    actions = ["export_as_excel"]
    def export_as_excel(self, request, queryset):
        meta = self.model._meta  # 用于定义文件名, 格式为: app名.模型类名
        field_names = [field.name for field in meta.fields]  # 模型所有字段名
        response = HttpResponse(content_type='application/msexcel')  # 定义响应内容类型
        response['Content-Disposition'] = f'attachment; filename={meta}.xlsx'  # 定义响应数据格式
        wb = Workbook()  # 新建Workbook
        ws = wb.active  # 使用当前活动的Sheet表
        ws.append(field_names)  # 将模型字段名作为标题写入第一行
        for obj in queryset:  # 遍历选择的对象列表

            for field in field_names:
                data = [f'{getattr(obj, field)}' for field in field_names]  # 将模型属性值的文本格式组成列表
            ws.append(data)
        wb.save(response)
        return response

    export_as_excel.short_description = 'Export Excel'  # 该动作在admin中的显示文字


admin.site.register(models.allocation_list, allocation_listAdmin)




class vacancy_listAdmin(admin.ModelAdmin):
    list_display = ('id','project', 'number_of_groups_allowed','number_of_groups_allocated',)
    list_filter = ['id','project', 'number_of_groups_allowed','number_of_groups_allocated',]
    list_per_page = 15
    actions = ["export_as_excel"]
    def export_as_excel(self, request, queryset):
        meta = self.model._meta  # 用于定义文件名, 格式为: app名.模型类名
        field_names = [field.name for field in meta.fields]  # 模型所有字段名
        response = HttpResponse(content_type='application/msexcel')  # 定义响应内容类型
        response['Content-Disposition'] = f'attachment; filename={meta}.xlsx'  # 定义响应数据格式
        wb = Workbook()  # 新建Workbook
        ws = wb.active  # 使用当前活动的Sheet表
        ws.append(field_names)  # 将模型字段名作为标题写入第一行
        for obj in queryset:  # 遍历选择的对象列表

            for field in field_names:
                data = [f'{getattr(obj, field)}' for field in field_names]  # 将模型属性值的文本格式组成列表
            ws.append(data)
        wb.save(response)
        return response

    export_as_excel.short_description = 'Export Excel'  # 该动作在admin中的显示文字

admin.site.register(models.vacancy_list, vacancy_listAdmin)





class project_infosAdmin(admin.ModelAdmin):

    list_display = ('group_id', 'title','number_of_groups_allowed',)
    list_filter = ['group_id', 'title','number_of_groups_allowed',]
    list_per_page = 15
    actions = ["export_as_excel"]
    def export_as_excel(self, request, queryset):
        meta = self.model._meta  # 用于定义文件名, 格式为: app名.模型类名
        field_names = [field.name for field in meta.fields]  # 模型所有字段名
        response = HttpResponse(content_type='application/msexcel')  # 定义响应内容类型
        response['Content-Disposition'] = f'attachment; filename={meta}.xlsx'  # 定义响应数据格式
        wb = Workbook()  # 新建Workbook
        ws = wb.active  # 使用当前活动的Sheet表
        ws.append(field_names)  # 将模型字段名作为标题写入第一行
        for obj in queryset:  # 遍历选择的对象列表

            for field in field_names:
                data = [f'{getattr(obj, field)}' for field in field_names]  # 将模型属性值的文本格式组成列表
            ws.append(data)
        wb.save(response)
        return response

    export_as_excel.short_description = 'Export Excel'  # 该动作在admin中的显示文字


admin.site.register(models.project_infos, project_infosAdmin)






class student_groupAdmin(admin.ModelAdmin):

    list_display = ('id','student_id', 'uni_key','group',)
    list_filter = ['id','student_id','uni_key','group',]

    list_per_page = 15
    actions = ["export_as_excel"]

    def export_as_excel(self, request, queryset):
        meta = self.model._meta  # 用于定义文件名, 格式为: app名.模型类名
        field_names = [field.name for field in meta.fields]  # 模型所有字段名
        response = HttpResponse(content_type='application/msexcel')  # 定义响应内容类型
        response['Content-Disposition'] = f'attachment; filename={meta}.xlsx'  # 定义响应数据格式
        wb = Workbook()  # 新建Workbook
        ws = wb.active  # 使用当前活动的Sheet表
        ws.append(field_names)  # 将模型字段名作为标题写入第一行
        for obj in queryset:  # 遍历选择的对象列表

            for field in field_names:
                data = [f'{getattr(obj, field)}' for field in field_names]  # 将模型属性值的文本格式组成列表
            ws.append(data)
        wb.save(response)
        return response

    export_as_excel.short_description = 'Export Excel'  # 该动作在admin中的显示文字


admin.site.register(models.student_group, student_groupAdmin)





class group_preferenceAdmin(admin.ModelAdmin):

    list_display = ( 'group_name','project_pref1','project_pref2','project_pref3',)
    list_filter = ['group_name','project_pref1','project_pref2','project_pref3',]
    list_per_page = 15
    actions = ["export_as_excel"]
    def export_as_excel(self, request, queryset):
        meta = self.model._meta  # 用于定义文件名, 格式为: app名.模型类名
        field_names = [field.name for field in meta.fields]  # 模型所有字段名
        response = HttpResponse(content_type='application/msexcel')  # 定义响应内容类型
        response['Content-Disposition'] = f'attachment; filename={meta}.xlsx'  # 定义响应数据格式
        wb = Workbook()  # 新建Workbook
        ws = wb.active  # 使用当前活动的Sheet表
        ws.append(field_names)  # 将模型字段名作为标题写入第一行
        for obj in queryset:  # 遍历选择的对象列表

            for field in field_names:
                data = [f'{getattr(obj, field)}' for field in field_names]  # 将模型属性值的文本格式组成列表
            ws.append(data)
        wb.save(response)
        return response

    export_as_excel.short_description = 'Export Excel'  # 该动作在admin中的显示文字


admin.site.register(models.group_preference, group_preferenceAdmin)









admin.site.site_title="Admin Management"
admin.site.site_header="Admin Management"
admin.site.index_title="Admin Management"
