from rest_framework.views import APIView
from django.shortcuts import render


# 数据首页
class Login(APIView):
    def get(self,request):
        return render(request, "login.html")