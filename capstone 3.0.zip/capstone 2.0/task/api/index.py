from rest_framework.views import APIView
from django.shortcuts import render
from database.models import UserInfo


# 数据首页
class Index(APIView):
    def get(self, request):

        data = {'context': UserInfo.objects.all}

        return render(request, 'index.html', data)
