from rest_framework.views import APIView
from django.shortcuts import render, redirect, HttpResponse
from database import models
from django.http import JsonResponse


class Login(APIView):

    authentication_classes = []

    def get(self, request):
        return render(request, "login.html")

    def post(self, request):
        username = str(request.data.get("username"))
        password = str(request.data.get("password"))
        message = {}
        # 认证账号密码
        user = models.UserInfo.objects.filter(username=username,password=password).first()
        if user:
            request.session['username'] = username
            message['code'] = 200
            message['message'] = "login success"
            return JsonResponse(message)
        else :
            message['code'] = 444
            message['message'] = "login failure"
            return JsonResponse(message)


