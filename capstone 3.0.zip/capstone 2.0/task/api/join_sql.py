from rest_framework.views import APIView
from django.shortcuts import render
import pandas as pd
from database import models
import csv
import os
# 获取相对路径
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def JoinSql(request):
    #try:
        import csv

        group_preference = []  # group_id, project_pref1, project_pref2, project_pref3
        try:
            with open(BASE_DIR + '\\media\\files\\group_preference.csv') as f:
                row = csv.reader(f, delimiter=',')
                next(row)  # read first row
                for r in row:
                    group_preference.append(r)
        except:
            return render(request, "upload.html", {"message": "Sorry! Miss group_preference.csv"})
    # print(group_preference)

        project_infos = []  # group_id, title, number_of_groups_allowed
        try:
            with open(BASE_DIR + '\\media\\files\\project_infos.csv') as f:
                row = csv.reader(f, delimiter=',')
                next(row)  # read first row
                for r in row:
                    project_infos.append(r)
        except:
            return render(request, "upload.html", {"message": "Sorry! Miss project_infos.csv"})

    # print(project_infos)

        student_groups = []  # student_id, uni_key, group_id
        try:
            with open(BASE_DIR + '\\media\\files\\student_groups.csv') as f:
                row = csv.reader(f, delimiter=',')
                next(row)  # read first row
                for r in row:
                    student_groups.append(r)
        except:
            return render(request, "upload.html", {"message": "Sorry! Miss student_groups.csv"})

    # print(student_groups)

    # initialize allocation list
        allocation_list = []
    # for row in group_preference:
    #    allocation_list.append([row[0], '0'])

    # initialize project vacancy list
        vacancy_list = []
        for row in project_infos:
            vacancy_list.append([row[0], int(row[2]), 0])
        # project_id, number_of_groups_allowed, number_of_groups_allocated

    # print(vacancy_list)

    # challenge 4 related
            group_dic = {}
            for row in student_groups:
                if row[2] not in group_dic:
                    group_dic[row[2]] = [(row[0], row[1])]
                else:
                    group_dic[row[2]].append((row[0], row[1]))  # studentID, unikey

    # print(group_dic)
    # group merging
        def merge(groupID):
        # get all groups that have less than 4 members
            print(groupID)
            num_of_members = len(group_dic[groupID])
            if num_of_members >= 4:
                print("Do not need to be merged.")
                return

            illegal_group_dic = {}
            for key in group_dic.keys():
                if len(group_dic[key]) <= 5 - num_of_members and len(group_dic[key]) >= 4 - num_of_members:
                    illegal_group_dic[key] = group_dic[key]
            print(
                "The groups with between " + str(4 - num_of_members) + " and " + str(5 - num_of_members) + " members are: ")
            for item in illegal_group_dic:
                print("Group " + item + ": " + str(len(illegal_group_dic[item])) + " members")
        # print(illegal_group_dic.keys())

            groupID_preference = []
        # find preference of given groupID
            for group in group_preference:
                if group[0] == groupID:
                    groupID_preference = [group[1], group[2], group[3]]
                    break
            if len(groupID_preference) == 0:
                print("Not found")
                return  # not found

            relevant_groups = []
        # merge groups with at least one common preference
            for i in range(len(groupID_preference)):  # 1, 2, 3
                gIDpref = groupID_preference[i]
                for group in group_preference:
                    if group_dic == None or group[0] not in group_dic.keys():
                        continue
                    elif len(group_dic[group[0]]) > 5:  # ignore groups with more than 5
                        continue
                    elif group[0] not in illegal_group_dic.keys():
                        continue

                # add to relevant_groups if they share at least one common preference

                    if gIDpref in group[1:]:
                        if group[0] not in relevant_groups:
                            relevant_groups.append(group[0])

        # merge the user chosen group
            if len(relevant_groups) == 0:
                print("There are no relevent groups with at least one common preference")
            elif len(relevant_groups) != 0:
                print("The relevant groups are: ")
                for group in relevant_groups:
                    pref = group_preference[[g[0] for g in group_preference].index(group)][1:]
                    print("Group " + group + " with preference " + str(pref) + " that has " + str(
                        len(group_dic[group])) + " members")

                chosen = relevant_groups[0]  # input("Enter the group ID you want to merge with group "+groupID+": ")
            # while (chosen not in relevant_groups) or (chosen == groupID):
            #    chosen = input("Error. Enter the group ID you want to merge with group "+groupID+": ")

                print("Group " + groupID + " merged with Group " + chosen)
            # modify groupID
                for stdgroup in student_groups:
                    if stdgroup[2] == chosen:
                        stdgroup[2] = groupID
                group_dic[groupID] = group_dic[group[0]] + group_dic[groupID]
            # delete the other merged group
                for group in group_preference:
                    if group[0] == chosen:
                        del group_preference[group_preference.index(group)]

                print()

            return

    # allocate


        def allocate():
            for group in group_preference:
        # challenge 4 related
                if group_dic == None or group[0] not in group_dic.keys():
            # print(1)
                    continue
                elif len(group_dic[group[0]]) < 4 or len(group_dic[group[0]]) > 5:
            # print(len(group_dic[group[0]]))
                    continue

                for project in vacancy_list:
                    if (group[1] == project[0]) and (project[1] > project[2]):
                # check first preference, if there are vacancies
                        allocation_list.append([group[0], project[0]])
                        project[2] += 1
                        break
                    elif (group[2] == project[0]) and (project[1] > project[2]):
                # check second preference, if there are vacancies
                        allocation_list.append([group[0], project[0]])
                        project[2] += 1
                        break
                    elif (group[3] == project[0]) and (project[1] > project[2]):
                # check third preference, if there are vacancies
                        allocation_list.append([group[0], project[0]])
                        project[2] += 1
                        break

        def procedure():
            gid = input("Enter the group ID you want to merge (Q to quit): ")
            if gid == "Q" or gid == "q":
                return True
            elif gid in group_dic.keys():
                merge(gid)
                return True
            print("Group ID not found. ")
            return False

    # main
    # merged = procedure() # merge(5)
    # while merged == False:
    #    merged = procedure()
        for group in group_preference:
            if group != None:
                merge(group[0])
        allocate()
# print("The allocation_list is: ")
# print(allocation_list)
# print("The vacancy_list is: ")
# print(vacancy_list)

        try:
            with open(BASE_DIR + '\\media\\allocation_list.csv', 'w', newline='') as f1:
                writer = csv.writer(f1)
                writer.writerow(['group_id', 'project_id'])
                for i in allocation_list:
                    writer.writerow(i)
        except:
            return render(request, "upload.html", {"message": "Sorry! Miss allocation_list.csv"})

        try:
            with open(BASE_DIR + '\\media\\vacancy_list.csv', 'w', newline='') as f2:
                writer = csv.writer(f2)
                writer.writerow(['project_id', 'number_of_groups_allowed', 'number_of_groups_allocated'])
                for i in vacancy_list:
                    writer.writerow(i)
        except:
            return render(request, "upload.html", {"message": "Sorry! Miss vacancy_list.csv"})


        try:
            with open(BASE_DIR + '\\media\\files\\student_groups.csv', 'w', newline='') as f3:
                writer = csv.writer(f3)
                writer.writerow(['student_id', 'uni_key', 'group_id'])
                for i in student_groups:
                    writer.writerow(i)
        except:
            return render(request, "upload.html", {"message": "Sorry! Miss student_groups.csv"})

        try:
            with open(BASE_DIR + '\\media\\files\\group_preference.csv', 'w', newline='') as f4:
                writer = csv.writer(f4)
                writer.writerow(['group_id', 'project_pref1', 'project_pref2', 'project_pref3'])
                for i in group_preference:
                    writer.writerow(i)
        except:
            return render(request, "upload.html", {"message": "Sorry! Miss group_preference.csv"})


        # 导入数据库
        models.project_infos.objects.all().delete()
        models.student_group.objects.all().delete()
        models.allocation_list.objects.all().delete()
        models.vacancy_list.objects.all().delete()
        models.allocation_condition.objects.all().delete()
        models.group_preference.objects.all().delete()

        # project_infos.csv
        try:
            data = pd.read_csv(BASE_DIR + '\\media\\files\\project_infos.csv')
        except:
            return render(request, "upload.html", {"message": "Sorry! Miss project_infos.csv"})


        for row in zip(data['group_id'], data['title'], data['number_of_groups_allowed']):
            models.project_infos.objects.create(group_id=row[0], title=row[1], number_of_groups_allowed=row[2])

        # group_preference.csv
        try:
            data = pd.read_csv(BASE_DIR + '\\media\\files\\group_preference.csv')
        except:
            return render(request, "upload.html", {"message": "Sorry! Miss group_preference.csv"})


        for row in zip(data['group_id'], data['project_pref1'], data['project_pref2'], data['project_pref3']):
            models.group_preference.objects.create(group_name=row[0], project_pref1=row[1], project_pref2=row[2], project_pref3=row[3])

        # vacancy_list.csv
        try:
            data = pd.read_csv( BASE_DIR + '\\media\\vacancy_list.csv')
        except:
            return render(request, "upload.html", {"message": "Sorry! Miss vacancy_list.csv"})

        for row in zip(data['project_id'], data['number_of_groups_allowed'], data['number_of_groups_allocated']):
            if int(row[1]) > int(row[2]):
                models.vacancy_list.objects.create(project_id=row[0], number_of_groups_allowed=True,
                                                   number_of_groups_allocated=False)
            elif int(row[1]) < int(row[2]):
                models.vacancy_list.objects.create(project_id=row[0], number_of_groups_allowed=False,
                                                   number_of_groups_allocated=True)
            else:
                models.vacancy_list.objects.create(project_id=row[0], number_of_groups_allowed=True,
                                                   number_of_groups_allocated=True)
        # allocation_condition

        try:
            data = pd.read_csv(BASE_DIR + '\\media\\vacancy_list.csv')
        except:
            return render(request, "upload.html", {"message": "Sorry! Miss vacancy_list.csv"})


        for row in zip(data['project_id'], data['number_of_groups_allowed'], data['number_of_groups_allocated']):
            models.allocation_condition.objects.create(project_id=row[0], number_of_groups_allowed=row[1],
                                                number_of_groups_allocated=row[2])

        # allocation_list
        try:
            data = pd.read_csv(BASE_DIR + '\\media\\allocation_list.csv')
        except:
            return render(request, "upload.html", {"message": "Sorry! Miss allocation_list.csv"})
        for row in zip(data['group_id'], data['project_id']):
            models.allocation_list.objects.create(group_id=row[0], project_id=row[1])

        # studdent_group.csv
        try:
            data = pd.read_csv( BASE_DIR + '\\media\\files\\student_groups.csv')
        except:
            return render(request, "upload.html", {"message": "Sorry! Miss student_groups.csv"})
        for row in zip(data['student_id'], data['uni_key'], data['group_id']):
            models.student_group.objects.create(student_id=row[0], uni_key=row[1], group_id=row[2])

        return render(request, "upload.html",{"message": "upload to database success!"})
    #except:
     #   return render(request, "upload.html", {"message": "Lack of csv document! Check it again!"})