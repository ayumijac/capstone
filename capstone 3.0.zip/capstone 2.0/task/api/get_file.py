
import traceback
from rest_framework.views import APIView
from django.http import JsonResponse
import os


# 获取相对路径
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class Files(APIView):

    def post(self, request):
        try:
            message={}
            # 接收文件
            file_obj = request.FILES.get('file',None)

            file_path = BASE_DIR + "/media/files/"

            if not os.path.exists(file_path):
                os.makedirs(file_path)
            # delete files_path
            # shutil.rmtree(file_path)
            # if not  path is exists
            if not os.path.exists(file_path):
                os.makedirs(file_path)
            # clear blank
            # down_path = "\\media\\files" + "\\{}".format(file_obj.name)
            # down_path = down_path.replace(" ","")
            # print(file_path)
            # file_path join the sql
            with open(file_path + "/" + file_obj.name , 'wb+') as f:
                for chunk in file_obj.chunks():
                    f.write(chunk)

            message['code'] = 200
            message['message'] = "upload success"
            return JsonResponse(message)
        except:
            msg = traceback.format_exc()
            message['code'] = 444
            message['message'] = "upload failure"
            return JsonResponse(message)

