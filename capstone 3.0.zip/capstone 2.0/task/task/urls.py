"""task URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.contrib import admin
from django.views.generic import RedirectView

from api import get_file, index, join_sql, upload, data, data_list, href_login, href_register, register, login, href_schema

urlpatterns = [
    url(r'^admin/', admin.site.urls),

    url(r'upload$',upload.Upload.as_view()),

    url(r'data$',data.Index.as_view()),

    url(r'data/list$', data_list.Data.as_view()),

    url(r"join/sql$",join_sql.JoinSql),
    # 上传文件
    url("files/up/$", get_file.Files.as_view()),

    # 首页
    url(r'^$', index.Index.as_view()),
    # 登录跳转
    url('login/$', href_login.Login.as_view()),
    # 注册跳转
    url('register/$', href_register.Register.as_view()),
    # 注册接口
    url('register/create/$', register.Register.as_view()),
    # 登录接口
    url('login/auth/$', login.Login.as_view()),
    # schema
    url(r'schema$', href_schema.Showschema.as_view()),
]
