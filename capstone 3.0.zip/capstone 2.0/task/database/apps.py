from django.apps import AppConfig


class DalConfig(AppConfig):
    name = 'database'
    verbose_name = "database"